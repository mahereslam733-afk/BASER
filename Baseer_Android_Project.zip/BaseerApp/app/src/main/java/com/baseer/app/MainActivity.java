package com.baseer.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status; TextToSpeech tts; SpeechRecognizer recognizer; final int REQ_AUDIO=20;
    int navy=Color.rgb(17,21,61), white=Color.WHITE;
    @Override public void onCreate(Bundle b){super.onCreate(b); build(); initSpeech();}
    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,24,28,24); root.setBackgroundColor(Color.WHITE);
        TextView title=new TextView(this); title.setText("بصير\nرفيقك في كل خطوة"); title.setTextSize(30); title.setTextColor(navy); title.setGravity(Gravity.CENTER); title.setContentDescription("بصير، رفيقك في كل خطوة");
        root.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        status=new TextView(this); status.setText("مرحبًا بك. اختر خدمة أو قل: قراءة، تعرف، عملات، مساعدة، ملاحة، محتوى، خدمات"); status.setTextSize(18); status.setTextColor(navy); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,0,1));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2); grid.setRowCount(4);
        add(grid,"📖 قراءة النصوص",Color.rgb(94,53,177),v->read()); add(grid,"👁 التعرف",Color.rgb(46,125,50),v->recognize());
        add(grid,"💰 العملات",Color.rgb(239,108,0),v->money()); add(grid,"🤝 مساعدة بشرية",Color.rgb(21,101,192),v->volunteer());
        add(grid,"🧭 الملاحة",Color.rgb(0,137,123),v->navigate()); add(grid,"🛠 خدمات يومية",Color.rgb(198,40,40),v->daily());
        add(grid,"🔊 المحتوى الصوتي",Color.rgb(109,76,65),v->content()); add(grid,"⚙ الإعدادات",Color.DKGRAY,v->settings());
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,6));
        Button voice=new Button(this); voice.setText("🎙 تحدث مع بصير"); voice.setTextSize(20); voice.setOnClickListener(v->listen()); root.addView(voice,new LinearLayout.LayoutParams(-1,70));
        setContentView(root);
    }
    void add(GridLayout g,String text,int color,View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setTextSize(17);b.setTextColor(Color.WHITE);b.setBackgroundColor(color);b.setOnClickListener(l);b.setContentDescription(text);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=150;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(6,6,6,6);g.addView(b,p);}
    void initSpeech(){tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("ar","EG"));}); if(SpeechRecognizer.isRecognitionAvailable(this)) recognizer=SpeechRecognizer.createSpeechRecognizer(this);}
    void speak(String s){status.setText(s); if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"baseer");}
    void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO);return;} Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"قل اسم الخدمة");startActivityForResult(i,100);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==100&&c==RESULT_OK&&d!=null){ArrayList<String> x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty())route(x.get(0));}}
    void route(String q){q=q.toLowerCase(Locale.ROOT);if(q.contains("قراءة")||q.contains("اقرأ"))read();else if(q.contains("تعرف")||q.contains("صورة")||q.contains("شيء"))recognize();else if(q.contains("عملة")||q.contains("فلوس"))money();else if(q.contains("مساعدة")||q.contains("متطوع"))volunteer();else if(q.contains("ملاحة")||q.contains("اتجاه")||q.contains("مكان"))navigate();else if(q.contains("محتوى")||q.contains("كتاب"))content();else if(q.contains("خدمات"))daily();else speak("لم أفهم الطلب. قل قراءة أو تعرف أو عملات أو مساعدة أو ملاحة أو محتوى أو خدمات");}
    void read(){speak("وضع قراءة النصوص. في النسخة الأولى يمكنك اختيار ملف نصي أو استخدام خدمة قراءة النصوص في الجهاز. سيتم إضافة التعرف الضوئي على الحروف في النسخة التالية.");}
    void recognize(){speak("وضع التعرف الذكي. سيتم توجيه الكاميرا للتعرف على الأشياء والصور. هذه النسخة الأولية تجهز الواجهة ومسار الاستخدام، وإضافة نموذج الرؤية الذكي تحتاج خدمة أو نموذجًا محليًا.");}
    void money(){speak("وضع التعرف على العملات. وجّه الكاميرا إلى العملة. التعرف الآلي على العملات يحتاج نموذج رؤية مخصص للعملات المصرية قبل النشر النهائي.");}
    void volunteer(){speak("سيتم فتح الاتصال بالمساعد البشري. اختر رقم المساعدة الذي تضيفه من الإعدادات."); String n=""; Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+n));startActivity(i);}
    void navigate(){speak("سأفتح الخرائط للتوجيه. يمكنك اختيار وجهتك بالصوت أو من الخريطة.");Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="));i.setPackage("com.google.android.apps.maps");try{startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=")));}}
    void content(){speak("المحتوى الصوتي: هذه المساحة مخصصة للكتب والمقالات والمواد الصوتية. يمكنك إضافة ملفاتك الصوتية من الهاتف في النسخة القادمة.");}
    void daily(){new AlertDialog.Builder(this).setTitle("الخدمات اليومية").setItems(new String[]{"التعرف على الألوان","الحاسبة الصوتية","قراءة الباركود","ملاحظات صوتية"},(d,w)->speak("اخترت "+((AlertDialog)d).getListView().getItemAtPosition(w))).show();}
    void settings(){new AlertDialog.Builder(this).setTitle("إعدادات بصير").setMessage("اللغة: العربية\nالصوت: عربي\nواجهة مبسطة\nدعم العمل دون إنترنت للوظائف المتاحة\nرقم المساعدة البشرية يمكن إضافته لاحقًا\n\nهذه نسخة أولية قابلة للتطوير قبل النشر على Google Play.").setPositiveButton("حسنًا",null).show();}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();if(recognizer!=null)recognizer.destroy();super.onDestroy();}
}
